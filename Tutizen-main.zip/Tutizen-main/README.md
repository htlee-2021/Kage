# Tutizen
We are a tutor website

How To Use
Simply use our link: https://tutizen-c8f64.web.app/
Or if you want to host it on your local machine, go into public folder and start from index.html
1)Sign up
2)browse for tutor (you can search by education lvl and subject)
3)click on tutor you are interested in and view their profile
4)You can then chat with them or book them
5)You can view your bookings and reviews page by clicking the dropdown on the top right of the nav bar
6)Sign up as a tutor if you are interested as well!

Other folders
1)Security Report
    a)This is the report generated after running our website through OWASP

2)Tutor Generator
    a)This is the helper function written to generate random but believeable tutor profiles to populate our database
    b)For your viewing pleasure